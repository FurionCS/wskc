package org.cs.basic.auth;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * 用来确定那些方法由那些角色访问
 * 属性有一个role：如果role的值为base表示这个方法可以被所有登录用户访问
 * 如果为role_public表示只能文章发布人员可以访问
 * 如果某个方法中没有加入表示只有管理员访问
 * @author Mr.Cheng
 *
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface AuthMethod {
	public String role() default "base";
}
