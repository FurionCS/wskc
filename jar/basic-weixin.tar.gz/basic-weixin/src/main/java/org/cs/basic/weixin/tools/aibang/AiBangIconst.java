package org.cs.basic.weixin.tools.aibang;

/**
 * 
 * @author xuxile
 *
 */
public class AiBangIconst {
	public static final String AI_BANG_API_KEY = "f56b391c336fadf50c039ee7f39e1aef";
}
