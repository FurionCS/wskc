package org.cs.basic.weixin.notice.model;

/**
 * 群发文字消息类的text属�?
 * @author xuxile 
 **/
public class Mptext {

	private String content;
	
	public Mptext(String content){
		this.content=content;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	
}
