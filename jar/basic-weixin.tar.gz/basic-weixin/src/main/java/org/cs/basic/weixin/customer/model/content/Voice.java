package org.cs.basic.weixin.customer.model.content;

/**
 * �����ͷ���Ϣ����
 * @author xuxile
 *
 */
public class Voice {

	private String media_id;

	public String getMedia_id() {
		return media_id;
	}

	public void setMedia_id(String mediaId) {
		media_id = mediaId;
	}
}
