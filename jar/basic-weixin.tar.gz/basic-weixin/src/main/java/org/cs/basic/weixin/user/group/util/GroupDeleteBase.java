package org.cs.basic.weixin.user.group.util;

public class GroupDeleteBase {

	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public GroupDeleteBase(String id) {
		super();
		this.id = id;
	}

	public GroupDeleteBase() {
		super();
	}

	
	
}
