package org.cs.basic.weixin.customer.model.content;

/**
 * �ı��ͷ���Ϣ����
 * @author xuxile
 *
 */
public class Text {

	private String content;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	
}
