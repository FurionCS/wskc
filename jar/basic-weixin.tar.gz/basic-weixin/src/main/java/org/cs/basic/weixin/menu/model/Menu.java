package org.cs.basic.weixin.menu.model;

/**
 * 菜单
 * @author xuxile
 */
public class Menu {
	private Button[] button;

	public Button[] getButton() {
		return button;
	}

	public void setButton(Button[] button) {
		this.button = button;
	}
}