package org.cs.basic.weixin.menu.model;

/**
 * 按钮的基�?
 * @author xuxile
 */
public class Button {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}