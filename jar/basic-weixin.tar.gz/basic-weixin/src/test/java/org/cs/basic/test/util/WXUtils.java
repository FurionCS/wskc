package org.cs.basic.test.util;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.cs.basic.weixin.common.AccessToken;

public class WXUtils {
	static String accessToken=null;
	public static String appid="wx9d7506e1b742b75d";
	public static String secret="b2adbe5e25486be92310a33b090534ee";
	public static Date createTime;
	
	/**
	 * token
	 * @return
	 */
	public static String getAccessToken(){
		if(StringUtils.isNotEmpty(accessToken)&&DateUtils.secondOfDate(new Date(), createTime)<7200){
	    	return accessToken;
	    }else{
	    	try {
	    		accessToken = AccessToken.getAccessToken(appid, secret);
	    		createTime=new Date();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return accessToken;
	    }
	}
}
