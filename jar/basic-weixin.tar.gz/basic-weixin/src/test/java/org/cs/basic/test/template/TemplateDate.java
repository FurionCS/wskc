package org.cs.basic.test.template;

import org.cs.basic.weixin.template.model.TemplateValueAndColor;

public class TemplateDate {
	private TemplateValueAndColor name;
	private TemplateValueAndColor username;
	private TemplateValueAndColor password;
	public TemplateValueAndColor getName() {
		return name;
	}
	public void setName(TemplateValueAndColor name) {
		this.name = name;
	}
	public TemplateValueAndColor getUsername() {
		return username;
	}
	public void setUsername(TemplateValueAndColor username) {
		this.username = username;
	}
	public TemplateValueAndColor getPassword() {
		return password;
	}
	public void setPassword(TemplateValueAndColor password) {
		this.password = password;
	}

	

}
