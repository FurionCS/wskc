package org.cs.basic.test.menu;

import java.util.ArrayList;
import java.util.List;

import org.cs.basic.test.util.WXUtils;
import org.cs.basic.weixin.menu.WxMenuManage;
import org.cs.basic.weixin.menu.model.Menu;
import org.cs.basic.weixin.menu.model.WeixinMenu;
import org.cs.basic.weixin.menu.util.MenuButtonUtil;
import org.junit.Test;

public class TestMenu {
	
	@Test
	public void getMenuNow() throws Exception{
		System.out.println(WxMenuManage.getMenuInfo(WXUtils.getAccessToken()));
	}
	@Test
	public void deleteMenu() throws Exception{
		WxMenuManage.deleteMenu(WXUtils.getAccessToken());
	}
	@Test
	public void createMenuInfo() throws Exception{
		List<WeixinMenu> menuList=new ArrayList();
	//	WeixinMenu weixinMenu=new WeixinMenu("2", "个人中心", 2, "1", "view",null, "456", "http://1h69151v02.51mypc.cn/mutualaid/user/showUserInfo");
		
		WeixinMenu weixinMenu2=new WeixinMenu("1", "进入系统", 1, "1", "view",null, "123", "http://votefe.leanapp.cn/#/login");
		menuList.add(weixinMenu2);
	//	menuList.add(weixinMenu);
		Menu menu=MenuButtonUtil.getMenu(menuList);
		String create_menu_json=net.sf.json.JSONObject.fromObject(menu).toString();
		System.out.println(create_menu_json);
		String errorcode=WxMenuManage.createMenu(create_menu_json, WXUtils.getAccessToken());
		System.out.println(errorcode);
	}
	

}
