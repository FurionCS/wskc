package org.cs.basic.test.wxmateriaList;

import java.util.List;

import org.cs.basic.weixin.common.AccessToken;
import org.cs.basic.weixin.material.WxMaterialList;
import org.junit.Test;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class TestWxMaterialList {
	
	@Test
	public void testGetMaterialList() throws Exception{
	/*	String accessToken=AccessToken.getAccessToken("", "");
		System.out.println(accessToken);
		JSONObject obj=WxMaterialList.getMaterialList("image", "8", "2", accessToken);
		JSONArray jsonArray=new JSONArray((List<Object>) obj.get("item"));
		JSONObject obj2=(JSONObject) jsonArray.get(0);
		System.out.println(obj2.get("media_id"));*/
	}

}
